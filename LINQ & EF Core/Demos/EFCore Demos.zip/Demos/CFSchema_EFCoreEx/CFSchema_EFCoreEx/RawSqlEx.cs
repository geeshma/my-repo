﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CFSchema_EFCoreEx.Models;
using CFSchema_EFCoreEx.Data;
using Microsoft.EntityFrameworkCore; // Mandate to perform RawSql
using System.Data.SqlClient;

namespace CFSchema_EFCoreEx
{
    public class RawSqlEx
    {
        static CodeFirstContext ctx;

        static RawSqlEx()
        {
            ctx = new CodeFirstContext();            
                
        }

        public static void DisplayAllHouse()
        {
            var result = ctx.Houses.
                FromSql("Select * from [Ram].[House]").ToList();

            foreach (var res in result)
            {
                Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", res.HouseId, res.HouseName, res.TotalMembers);
            }
        }

        //Display details from House table specifying column list in the query
        public static void DisplaySpecificColumnData()
        {
            //Whatever columns specified the class property, all Column names must be inculded inthe select query of FromSql().
            //Otherwise it will throw InvalidOperationException.

            var result = ctx.Houses.
                FromSql("Select HouseId, HouseName, TotalMembers from [Ram].[House]").ToList();

            foreach (var res in result)
            {
                Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", res.HouseId, res.HouseName, res.TotalMembers);
            }
        }

        
        public static void ExecuteParamQuery()
        {
            ////Query-1

            //string Hid = "H010";

            //var result = ctx.Houses.
            //    FromSql("Select * from [Ram].[House] where HouseId= {0}", Hid).SingleOrDefault();

            //if(result is House)
            //{
            //    Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", result.HouseId, result.HouseName, result.TotalMembers);
            //}
            //else
            //{
            //    Console.WriteLine("No Such House Id Exist");
            //}

            int total = 8;

            int lowlimit = 6;
            int uplimit = 10;

            ////Below logic using Fluent-API 

            //var result = ctx.Houses.
            //    Where(h => h.TotalMembers > 8).
            //    FromSql("Select * from [Ram].[House]").ToList(); 

            //// We can write the logic using Noram Linq Expression

            //var result = ctx.Houses.
            //    FromSql("Select * from [Ram].[House] where Totalmembers > {0}", total).ToList();

            //// We can write more than one condition in single Query using FromSql()
            var result = ctx.Houses.
                FromSql("Select * from [Ram].[House] where Totalmembers between {0} and {1}", lowlimit, uplimit).ToList();

            if(result.Count >0)
            {
                foreach(var res in result)
                {
                    Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", res.HouseId, res.HouseName, res.TotalMembers);
                }
            }
            else
            {
                Console.WriteLine("No House present"); ;
            }
        }

        public static void ExecuteSP()
        {
            ////Calling basic Stored procedure

            //var result = ctx.Houses.
            //    FromSql("Exec [Ram].[DisplayAllHouse]").ToList();


            ////Calling Stored Procedure with Parameters

            //var param1 = new SqlParameter("@total", 14);

            //var result = ctx.Houses.
            //    FromSql("Exec [Ram].[DisplayHousewithParam] @total", param1).ToList();


            ////Calling Stored Procedure with Multiple Parameters

            var param1 = new SqlParameter("@min", 13);
            var param2 = new SqlParameter("@max", 14);

            var result = ctx.Houses.
                FromSql("Exec [Ram].[DisplayHouseMultiParam] @min,@max", param1, param2).ToList();
            if (result.Count > 0)
            {
                foreach (var res in result)
                 {
                    Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", res.HouseId, res.HouseName, res.TotalMembers);
                }
            }
            else
            {
                Console.WriteLine("No House present"); ;
            }
        }

        public static void ExecuteDML()
        {
            string qry = "Insert into Ram.House (HouseId,HouseName,TotalMembers) values(@hid,@hname,@total)";
            SqlParameter param1 = new SqlParameter("@hid", "H004");
            SqlParameter param2 = new SqlParameter("@hname", "Nehru Block");
            SqlParameter param3 = new SqlParameter("@total",5);

            var result = ctx.Database.ExecuteSqlCommand(qry, param1, param2, param3);

            if (result >0)
            {
                Console.WriteLine("Record Successfully Inserted");
            }
            else
            {
                Console.WriteLine("No Record Inserted");
            }
        }

        public static void ExecuteSPDML()
        {
            SqlParameter param1 = new SqlParameter("@hid", "H006");
            SqlParameter param2 = new SqlParameter("@hname", "Mahindra City");
            SqlParameter param3 = new SqlParameter("@total", 4);

            ////Either this way

            //var result = ctx.Database.ExecuteSqlCommand("[Ram].[InsertHouse] @hid,@hname,@total",param1,param2,param3);

            ////or this way

            var result = ctx.Database.ExecuteSqlCommand("[Ram].[InsertHouse] @p0,@p1,@p2",parameters: new object[] { "H007", "Krishna Bhavan", 9 });

            if (result > 0)
            {
                Console.WriteLine("Record Successfully Inserted");
            }
            else
            {
                Console.WriteLine("No Record Inserted");
            }
        }
    }
}
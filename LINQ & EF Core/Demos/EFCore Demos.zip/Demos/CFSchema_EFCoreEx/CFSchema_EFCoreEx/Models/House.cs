﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CFSchema_EFCoreEx.Models
{
    [Table("House",Schema ="Ram")]
    public class House
    {
        [Key]
        [MaxLength(10)]
        public string HouseId { get; set; }

        [Required]
        [MaxLength(50)]
        public string HouseName { get; set; }

        [Required]
        
        public int TotalMembers {get; set;}

        public ICollection<Members> Members { get; set; }

    }
}

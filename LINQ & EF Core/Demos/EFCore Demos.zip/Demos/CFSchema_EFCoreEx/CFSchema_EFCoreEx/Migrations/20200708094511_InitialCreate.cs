﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CFSchema_EFCoreEx.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Ram");

            migrationBuilder.CreateTable(
                name: "House",
                schema: "Ram",
                columns: table => new
                {
                    HouseId = table.Column<string>(maxLength: 10, nullable: false),
                    HouseName = table.Column<string>(maxLength: 50, nullable: false),
                    TotalMembers = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_House", x => x.HouseId);
                });

            migrationBuilder.CreateTable(
                name: "Member",
                schema: "Ram",
                columns: table => new
                {
                    MemberID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    MemberName = table.Column<string>(maxLength: 50, nullable: false),
                    HouseId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Member", x => x.MemberID);
                    table.ForeignKey(
                        name: "FK_Member_House_HouseId",
                        column: x => x.HouseId,
                        principalSchema: "Ram",
                        principalTable: "House",
                        principalColumn: "HouseId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Member_HouseId",
                schema: "Ram",
                table: "Member",
                column: "HouseId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Member",
                schema: "Ram");

            migrationBuilder.DropTable(
                name: "House",
                schema: "Ram");
        }
    }
}

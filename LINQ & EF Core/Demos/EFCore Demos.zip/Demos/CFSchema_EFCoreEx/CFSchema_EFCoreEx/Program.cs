﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CFSchema_EFCoreEx.Models;
using CFSchema_EFCoreEx.Data;

namespace CFSchema_EFCoreEx
{
    public class Program
    {
        static CodeFirstContext ctx;

        static Program()
        {
            ctx = new CodeFirstContext();
        }


        //Code to display all data from tables with different schema
        static void DisplayHouseDetails()
        {

            var Housesdata = ctx.Houses.ToList();

            foreach (var hs in Housesdata)
            {
                Console.WriteLine("The House Id is: {0} with House Name: {1} and total Members in the house {2}", hs.HouseId, hs.HouseName, hs.TotalMembers);
            }

        }

        static void Main(string[] args)
        {
            // DisplayHouseDetails();

            //RawSqlEx.DisplayAllHouse();

            //RawSqlEx.DisplaySpecificColumnData();

            //RawSqlEx.ExecuteParamQuery();

            //RawSqlEx.ExecuteSP();

            //RawSqlEx.ExecuteDML();

            RawSqlEx.ExecuteSPDML();

            Console.ReadLine();

            
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore; // For inherit DbContext
using Microsoft.EntityFrameworkCore.SqlServer;
using CFSchema_Constring_EFCoreEx.Models;
using System.Text;
using Microsoft.Extensions.Configuration; //Needs for accessing config file in the project
using Microsoft.Extensions.Configuration.Json; //Accessing json file using Configuratin (through NuGet)
namespace CFSchema_Constring_EFCoreEx.CFSchemaConContext
{
    class CodeFirstContext:DbContext
    {
        public DbSet<Country> Countries {get; set;}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);

            //IConfigurationRoot config = new ConfigurationBuilder()
            //    .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            //    .AddJsonFile("appsettings.json")
            //    .Build();


            IConfigurationRoot config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            optionsBuilder.UseSqlServer(config.GetConnectionString("myCon"));

                

            

        }
    }
}

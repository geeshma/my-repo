﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using CFSchema_Constring_EFCoreEx.Models;
using CFSchema_Constring_EFCoreEx.CFSchemaConContext;

namespace CFSchema_Constring_EFCoreEx
{
    public class Program
    {
        static CodeFirstContext ctx;

        static Program()
        {
            ctx = new CodeFirstContext();
        }

        public static void AddCountry()
        {
            List<Country> cty = new List<Country>
            {
                new Country{CountryName = "India", TotalPopulation=1000000},
                new Country{CountryName = "USA", TotalPopulation=2500000},
                new Country{CountryName = "Australia", TotalPopulation=100000}
            };

            ctx.Countries.AddRange(cty);
            ctx.SaveChanges();

            Console.WriteLine("Country details added successfully");
        }


        static void Main(string[] args)
        {
            AddCountry();

            Console.ReadLine();
        }
    }
}

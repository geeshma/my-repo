﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using DBF_EFCore_TransactionEx.Models;
using Microsoft.EntityFrameworkCore;




namespace DBF_EFCore_TransactionEx
{
    class Program
    {
        //public static Training_16thMay_ChennaiContext ctx;

        //static Program()
        //{
        //    ctx = new Training_16thMay_ChennaiContext();
        //}

        public static void Manipulate()
        {
            using (Training_16thMay_ChennaiContext ctx = new Training_16thMay_ChennaiContext())
            {
                using (var trans = ctx.Database.BeginTransaction())
                {
                    try
                    {;
                        var newemp = new Employee { EmployeeName = "Raghu", DepartmentId = 50 };
                        ctx.Employee.Add(newemp);
                        ctx.SaveChanges();

                        // throw new Exception(); //This will throw the exception and the catch block will call the rollback statment which will rollback changes what was happened in the the db

                        var newdept = new Department { DepartmentId=110, DepartmentName = "Production" };
                        ctx.Department.Add(newdept);
                        ctx.SaveChanges();

                        trans.Commit();

                        Console.WriteLine("Changes updated successfully in the database");

                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                        Console.WriteLine("Error Occured: " + ex.Message);                        
                    }
                    Console.ReadLine();
                }
            }
           
        }

        static void Main(string[] args)
        {
            Manipulate();
        }
    }
}

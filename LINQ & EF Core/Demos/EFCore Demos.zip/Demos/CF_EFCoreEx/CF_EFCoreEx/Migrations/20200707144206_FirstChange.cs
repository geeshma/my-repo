﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CF_EFCoreEx.Migrations
{
    public partial class FirstChange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TId",
                table: "Players");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TId",
                table: "Players",
                nullable: false,
                defaultValue: 0);
        }
    }
}

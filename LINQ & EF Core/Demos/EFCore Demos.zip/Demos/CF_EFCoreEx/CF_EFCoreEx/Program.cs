﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CF_EFCoreEx.Models;
using CF_EFCoreEx.Data;

namespace CF_EFCoreEx
{
    class Program
    {
        static CodeFirstContext ctx;

        static Program()
        {
            ctx = new CodeFirstContext();  
        }

        static void AddTeams()
        {
            Team t1 = new Team { TeamName = "Italy", TeamPoints=5 };
            Team t2 = new Team { TeamName = "Brazil", TeamPoints=6 };
            Team t3 = new Team { TeamName = "England", TeamPoints=4 };

            ctx.Teams.Add(t1);
            ctx.Teams.AddRange(t2, t3);

            List<Team> tm = new List<Team>
            {
                new Team{TeamName="China", TeamPoints=1},
                new Team{TeamName="USA", TeamPoints=2}
            };

            ctx.Teams.AddRange(tm);

            ctx.SaveChanges();

            Console.WriteLine("Team Details Added Successfully");
                

        }

        static void DisplayTeams()
        {
            foreach(Team tm in ctx.Teams)
            {
                Console.WriteLine($"Team Id is {tm.TeamId} with Team Name is: {tm.TeamName} Securing {tm.TeamPoints} point(s)");
            }
        }

        static void UpdateTeams()
        {
            ////Fluent API

            //var tm = ctx.Teams
            //    .Where(t => t.TeamName == "China")
            //    .FirstOrDefault();

            //if (tm is Team)
            //{
            //    tm.TeamPoints = 0;
            //}

            //ctx.SaveChanges();

            //Console.WriteLine("Team Details updated");



            //Linq Expression
            var tm = (from t in ctx.Teams
                      where t.TeamName == "China"
                      select t).FirstOrDefault();

            if (tm is Team)
            {
                tm.TeamPoints = 1;
            }

            ctx.SaveChanges();

            Console.WriteLine("Team Details updated");

        }

        static void RemoveTeam()
        {
            Team tm = ctx.Teams
                .Where(t => t.TeamName == "USA")
                .FirstOrDefault();

            if(tm is Team)
            {
                ctx.Teams.Remove(tm);

            }
            ctx.SaveChanges();
            Console.WriteLine("Team Details Removed");
        }



        static void Main(string[] args)
        {

            // AddTeams();

            //DisplayTeams();

            //UpdateTeams();

            RemoveTeam();

            Console.ReadLine();
        }
    }
}

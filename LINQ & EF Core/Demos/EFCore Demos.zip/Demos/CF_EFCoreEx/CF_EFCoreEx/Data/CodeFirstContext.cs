﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore; // For inherit DbContext
using Microsoft.EntityFrameworkCore.SqlServer;
using CF_EFCoreEx.Models;


namespace CF_EFCoreEx.Data
{
    class CodeFirstContext : DbContext
    {

        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("server=NDAMSSQL\\SQLILEARN;database=Training_16thMay_Chennai;Integrated Security=false; user id=sqluser; password=sqluser");

        }

    }
}

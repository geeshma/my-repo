﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using DBF_DML_EFCoreEx.Models;

namespace DBF_DML_EFCoreEx
{
    class Program
    {
        public static Training_16thMay_ChennaiContext ctx;

        static Program()
        {
            ctx = new Training_16thMay_ChennaiContext();
        }


        //// Below code used to Add one record from the table
        private static void AddEmployee()
        {
            var newEmp = new Employee { EmployeeName = "Kandhan", DepartmentId = 40 };

            ctx.Employee.Add(newEmp);
            ctx.SaveChanges();
            Console.WriteLine("Employee Details Added Successfully");
        }

        
        //// Below code used to Add More than one record from the same table using AddRange method
        public static void AddEmployees()
        {
            var Emps = new List<Employee>
            {
                new Employee{EmployeeName= "Pranil", DepartmentId=60},
                new Employee{EmployeeName= "Allen", DepartmentId=50}
            };

            ctx.Employee.AddRange(Emps);
            ctx.SaveChanges();
            Console.WriteLine("More than One Employee Details Added Successfully");
        }


        /// Below code used to Add More than one record using param array from the same table using AddRange method
        public static void AddMutiRowDept()
        {
            var Dept_Data1 = new Department() { DepartmentId = 90, DepartmentName = "Transport" };
            var Dept_Data2 = new Department() { DepartmentId = 100, DepartmentName = "Maintenance" };

            ctx.Department.AddRange(Dept_Data1, Dept_Data2);

            ctx.SaveChanges();

            Console.WriteLine("More than One Departement Details Added Successfully");

        }

        
        //// Below Code used to update Employee Details 
        
        private static void UpdateEmp()
        {
            ////First Way

            //var EmpData = ctx.Employee.Find(29);
            //EmpData.EmployeeName = "Shiva";
            //ctx.Employee.Update(EmpData);
            //ctx.SaveChanges();

            //Console.WriteLine("Employee Details updated successfully");


            ////Second Way
            
            var EmpData = ctx.Employee.SingleOrDefault(emp => emp.EmployeeId == 29);
            EmpData.DepartmentId = 70;
            ctx.Employee.Update(EmpData);
            ctx.SaveChanges();

            Console.WriteLine("Employee Details updated successfully");
        }


        //// Below Code used to delete Employee Details 
        private static void DeleteEmp()
        {
            ////First way of Deleting Record

            //var EmpData = ctx.Employee.Find(29);
            //ctx.Employee.Remove(EmpData);
            //ctx.SaveChanges();
            //Console.WriteLine("Employee Details Deleted from the Table");

            ////Second Way

            var EmpData = ctx.Employee.SingleOrDefault(emp => emp.EmployeeId == 28);
            ctx.Employee.Remove(EmpData);
            ctx.SaveChanges();
            Console.WriteLine("Employee Details Deleted from the Table");
        }

        static void Main(string[] args)
        {
            //AddEmployee();

            //AddEmployees();

            //AddMutiRowDept();

            //UpdateEmp();

            DeleteEmp();

            Console.ReadLine();
        }

        
    }
}

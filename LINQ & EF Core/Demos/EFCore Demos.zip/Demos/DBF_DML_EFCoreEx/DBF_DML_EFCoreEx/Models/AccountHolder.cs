﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class AccountHolder
    {
        public int AccountId { get; set; }
        public string AcName { get; set; }
        public string City { get; set; }
        public string AccountType { get; set; }
        public int Amount { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class Customer
    {
        public int CustId { get; set; }
        public string CustName { get; set; }
        public string City { get; set; }
        public int Prodid { get; set; }
        public int Qty { get; set; }

        public Product Prod { get; set; }
    }
}

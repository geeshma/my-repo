﻿using System;
using System.Collections.Generic;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class BusDetails
    {
        public int BusId { get; set; }
        public string BusName { get; set; }
        public string FromLocation { get; set; }
        public int Fare { get; set; }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DBF_DML_EFCoreEx.Models
{
    public partial class Training_16thMay_ChennaiContext : DbContext
    {
        public Training_16thMay_ChennaiContext()
        {
        }

        public Training_16thMay_ChennaiContext(DbContextOptions<Training_16thMay_ChennaiContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AccountHolder> AccountHolder { get; set; }
        public virtual DbSet<BusDetails> BusDetails { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<FurnitureData> FurnitureData { get; set; }
        public virtual DbSet<PassengerDetails> PassengerDetails { get; set; }
        public virtual DbSet<Product> Product { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=NDAMSSQL\\SQLILEARN;Database=Training_16thMay_Chennai;Trusted_Connection=False;User ID=sqluser; Password=sqluser");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountHolder>(entity =>
            {
                entity.HasKey(e => e.AccountId);

                entity.ToTable("AccountHolder", "RAM");

                entity.Property(e => e.AccountId).HasColumnName("Account_Id");

                entity.Property(e => e.AcName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.AccountType)
                    .IsRequired()
                    .HasColumnName("Account_Type")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BusDetails>(entity =>
            {
                entity.HasKey(e => e.BusId);

                entity.ToTable("BusDetails", "RAM");

                entity.Property(e => e.BusId).HasColumnName("BusID");

                entity.Property(e => e.Fare).HasColumnName("fare");
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustId);

                entity.ToTable("Customer", "RAM");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CustName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Prod)
                    .WithMany(p => p.Customer)
                    .HasForeignKey(d => d.Prodid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Customer__Prodid__324172E1");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("DEPARTMENT", "RAM");

                entity.Property(e => e.DepartmentId)
                    .HasColumnName("DEPARTMENT_ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.DepartmentName)
                    .IsRequired()
                    .HasColumnName("DEPARTMENT_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("EMPLOYEE", "RAM");

                entity.Property(e => e.EmployeeId).HasColumnName("EMPLOYEE_ID");

                entity.Property(e => e.DepartmentId).HasColumnName("DEPARTMENT_ID");

                entity.Property(e => e.EmployeeName)
                    .IsRequired()
                    .HasColumnName("EMPLOYEE_NAME")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EMP_DEPT_DID");
            });

            modelBuilder.Entity<FurnitureData>(entity =>
            {
                entity.HasKey(e => e.ItemCode);

                entity.ToTable("FurnitureData", "RAM");

                entity.Property(e => e.ItemType)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Remarks)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PassengerDetails>(entity =>
            {
                entity.HasKey(e => e.PassengerId);

                entity.ToTable("Passenger_Details", "RAM");

                entity.Property(e => e.PassengerId).HasColumnName("Passenger_Id");

                entity.Property(e => e.BusNo)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FromLoc)
                    .IsRequired()
                    .HasColumnName("From_Loc")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerName)
                    .IsRequired()
                    .HasColumnName("Passenger_Name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ToLoc)
                    .IsRequired()
                    .HasColumnName("To_Loc")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.ProdId);

                entity.ToTable("Product", "RAM");

                entity.Property(e => e.ProdId).HasColumnName("ProdID");

                entity.Property(e => e.ProdName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DBF_EFCoreEx.Models;

namespace DBF_EFCoreEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating object of database context
            Training_16thMay_ChennaiContext ctx = new Training_16thMay_ChennaiContext();

            ////Demo for displaying all details from Employee Table

            //var Empresult = ctx.Employee.ToList();

            //foreach(var emp in Empresult)
            //{
            //    Console.WriteLine("Emp Name is: {0} and Dept Id is: {1}", emp.EmployeeName, emp.DepartmentId);
            //}



            ////Demo for displaying Employee details with filtering

            //var Empresult = ctx.Employee.OrderBy(emp => emp.DepartmentId).Where(emp => emp.DepartmentId > 40).ToList();

            //foreach (var emp in Empresult)
            //{
            //    Console.WriteLine("Emp Name is: {0} and Dept Id is: {1}", emp.EmployeeName, emp.DepartmentId);
            //}


            ////Demo for grouping employees with department name

            //var Groupresult = from empdata in ctx.Employee
            //                group empdata by empdata.DepartmentId
            //                into emp
            //                orderby emp.Key
            //                select emp;

            //foreach (var gp in Groupresult)
            //{
            //    Console.WriteLine("Dept id is: {0} and Number of Employee working : {1}", gp.Key,gp.Count());
            //}


            ////Demo for displaying data from more than one table using join

            var Multidata = (from empdata in ctx.Employee
                             join deptdata in ctx.Department 
                             on
                             empdata.DepartmentId equals deptdata.DepartmentId
                             select new { empdata.EmployeeName, deptdata.DepartmentName }).ToList();
            
            foreach(var Multi in Multidata)
            {
                Console.WriteLine("Employee {0} working in {1}",Multi.EmployeeName,Multi.DepartmentName);
            }

           

            Console.ReadLine();
        }
    }
}
